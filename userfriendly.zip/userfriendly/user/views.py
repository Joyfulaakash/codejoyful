import os
from django.forms import Media
from django.http import response
from pytube import Playlist,YouTube
from django.shortcuts import render
import random
from PIL import Image
import datetime
from translate import Translator
import contextlib
from .form import imagermForm,imageformatForm
from .models import imagerm,securityip,imageformatss,imagermformat,securityfinder,securitypasswds,imagemonformat,ipaddrs,securityurls,securityyoutube,grammerchecks
from userfriendly.settings import BASE_DIR,MEDIA_URL
from remove_bg_api import RemoveBg
import language_tool_python
tool = language_tool_python.LanguageTool('en-US')
try:
	from urllib.parse import urlencode		
except ImportError:
	from urllib import urlencode
try:
	from urllib.request import urlopen
except ImportError:
	from urllib2 import urlopen

# Create your views here.
def get_client_ip(request):
    now = datetime.datetime.now()
    showtime = now.strftime("%Y-%m-%d %H:%M:%S")
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip,showtime


def index(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='home',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.all().order_by('-Date')
    return render(request,'index.html',{'ip':ip})

def base(request):
    return render(request,'base.html')

def login(request):
    ip,showtime=get_client_ip(request)

    return render(request,"login.html",{'ip':ip})

def adminbase(request):
    ip,showtime=get_client_ip(request)
    ids = ipaddrs.objects.filter(ipaddrs=ip).order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})

def about(request):
    return render(request,"about.html")

def contact(request):
    return render(request,'contact.html')


def admingrammercheck(request):
    ip,showtime=get_client_ip(request)
    ids = grammerchecks.objects.filter(ipaddrs=ip,page='Spell Check').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date","Spell Check"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})

def adminsecurityfinder(request):
    ip,showtime=get_client_ip(request)
    ids = securityfinder.objects.filter(ipaddrs=ip,page='Translate').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date","Translation"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})
  

def translate(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Translate',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Translate').order_by('-Date')
    if request.method == 'POST':
        trans=request.POST['translate']
        sourcelang=request.POST['sourcelang']
        dislang=request.POST['dislang']
        print(trans,sourcelang,dislang)
        translator= Translator(from_lang=sourcelang,to_lang=dislang)
        translation = translator.translate(trans)
        print(translation)
        ips,showtime=get_client_ip(request)
        securitypasswd=securityfinder(ipaddrs=ips,page='Translation',Date=showtime,passwd=translation)
        securitypasswd.save()
        return render(request,"translate.html",{'ip':ip,'translation':translation})
    return render(request,"translate.html",{'ip':ip})

import requests
def get_location(ip_address):
    response = requests.get(f'https://ipinfo.io/{ip_address}?token=15366f8927df22').json()
    location_data = {
        "ip": ip_address,
        "city": response.get("city"),
        "region": response.get("region"),
        "country": response.get("country_name")
    }
    return location_data,response

def iplocation(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Ip Location',Date=showtime)
    ipaddr.save()
    urls,response=get_location(ip)
    print(response)
    securityyoutubes=securityip(ipaddrs=ip,page='Ip Location',Date=showtime,passwd=urls)
    securityyoutubes.save()
    ip = ipaddrs.objects.filter(page='Ip Location').order_by('-Date')
    return render(request,'iplocation.html',{'ip':ip,'id':id,'urls':response})
    

def grammercheck(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Spell Check',Date=showtime)
    
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Spell Check').order_by('-Date')
    if request.method == 'POST':
        url=request.POST['grammer']
        text=url
        matches = tool.check(text)
        my_mistakes = []
        my_corrections = []
        start_positions = []
        end_positions = []
        for rules in matches:
            if len(rules.replacements)>0:
                start_positions.append(rules.offset)
                end_positions.append(rules.errorLength+rules.offset)
                my_mistakes.append(text[rules.offset:rules.errorLength+rules.offset])
                my_corrections.append(rules.replacements[0])
        my_new_text = list(text)
        for m in range(len(start_positions)):
            for i in range(len(text)):
                my_new_text[start_positions[m]] = my_corrections[m]
                if (i>start_positions[m] and i<end_positions[m]):
                    my_new_text[i]=""
        my_new_text = "".join(my_new_text)
        
        tables=(list(zip(start_positions,end_positions,my_mistakes,my_corrections)))
        print(tables)
        ips,showtime=get_client_ip(request)
        try:
            grammercheck=grammerchecks(ipaddrs=ips,page='Spell Check',Date=showtime,passwd=my_new_text)
            print(grammercheck)
            grammercheck.save()
        except:
            pass
        return render(request,'grammercheck.html',{'ip':ip,'text':text,'my_new_text':my_new_text,'tables':tables})
    return render(request,'grammercheck.html',{'ip':ip})


def rembg(source):
    removebg = RemoveBg('4ExCTYEMJqNzTM9z9jFTttSM')
    source=str(BASE_DIR)+source
    destination=str(BASE_DIR)+MEDIA_URL+'images/temp.png'
    print(destination)
    image = removebg.remove_bg_file(input_path=source, out_path=destination, size="preview", raw=False)  
    print("Image was saved along the path: {}".format(image))
    return image,destination


def adminimagermbg(request):
    ip,showtime=get_client_ip(request)
    ids = imagermformat.objects.filter(ipaddrs=ip,page='Background Removebg').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Format","Image"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})


def imagermbg(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Background Removebg',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Background Removebg').order_by('-Date')
    if request.method == 'POST':
        form = imagermForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            images = imagerm.objects.last()
            u,image=rembg(images.Img.url) 
            print(str(BASE_DIR)+MEDIA_URL+'images/temp.png')
            ips,showtime=get_client_ip(request)
            securitypasswd=imagermformat(ipaddrs=ips,page='Background Removebg',Date=showtime,Img=MEDIA_URL+'images/temp.png')
            securitypasswd.save()
            return render(request, 'imagermbg.html',{'images': MEDIA_URL+'images/temp.png','ip':ip})
        else:
            images = imagerm.objects.all()
            form = imagermForm()
            return render(request, 'imagermbg.html', {'ip':ip,'form' : form})
        
    else:
        images = imagerm.objects.all()
        form = imagermForm()
        return render(request, 'imagermbg.html', {'ip':ip,'form' : form})


def adminimagformat(request):
    ip,showtime=get_client_ip(request)
    ids = imagemonformat.objects.filter(ipaddrs=ip,page='Image Formating').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Format","Image"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})


#imagemonformat
def imagformat(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Image Formating',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Image Formating').order_by('-Date')
    if request.method == 'POST':
        form = imageformatForm(request.POST, request.FILES)
  
        if form.is_valid():
            form.save()
            images = imageformatss.objects.last() 
            im = Image.open(images.Img)
            rgb_im = im.convert("RGB")
            im=str(images.Img)
            ime=str(images.Img)
            print(ime)
            ime=ime.split(".")[0]
            ime=im[:-len(im.split('.')[-1])]+str(images.format)
            ime=str(BASE_DIR)+MEDIA_URL +ime
            print(ime)
            rgb_im.save(ime)
            ips,showtime=get_client_ip(request)
            securitypasswd=imagemonformat(ipaddrs=ips,page='Image Formating',Date=showtime,format=ime,Img=MEDIA_URL +ime)
            securitypasswd.save()
            form = imageformatForm()
            return render(request, 'imagformat.html',{'images' :MEDIA_URL +ime ,'form' : form,'ip':ip})
    else:
        images = imageformatss.objects.all()
        form = imageformatForm()
    return render(request, 'imagformat.html', {'ip':ip,'form' : form})



def securityfinder(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Security Identity',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Security Identity').order_by('-Date')
    return render(request,'securityfinder.html',{'ip':ip})

def adminsecuritypasswd(request):
    ip,showtime=get_client_ip(request)
    ids = securitypasswds.objects.filter(ipaddrs=ip,page='Security Password').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date","Password"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})


def securitypasswd(request):
    ips,showtime=get_client_ip(request)
    ip = ipaddrs.objects.filter(page='Security Password').order_by('-Date')
    if request.method == 'POST':
        char_seq = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&'()*+,-./:;<=>?@[\]^_`{|}~"
        print("Enter the required length of the password ranging from 8 to 16: ")
        length = int(request.POST['passwd'])
        if length >= 8 :
            password = ''
            for len in range(length):
                random_char = random.choice(char_seq)
                password += random_char

            # print(password)
            list_pass = list(password)
            random.shuffle(list_pass)
            final_password = ''.join(list_pass)
            print(final_password)
            ips,showtime=get_client_ip(request)
            securitypasswd=securitypasswds(ipaddrs=ips,page='Security Password',Date=showtime,passwd=final_password)
            securitypasswd.save()
            return render(request,'securitypasswd.html',{'final_password':final_password,'ip':ip})
        else:
            print("Enter a suitable range")
    else:
        ipaddr=ipaddrs(ipaddrs=ips,page='Security Password',Date=showtime)
        ipaddr.save()
        return render(request,'securitypasswd.html',{'ip':ip})


def adminsecurityurlqr(request):
    ip,showtime=get_client_ip(request)
    ids = securityurls.objects.filter(ipaddrs=ip,page='Security URL/QRcode').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date","URL Shortner"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})

def securityurlqr(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Security URL/QRcode',Date=showtime)
    ipaddr.save()
    ip = ipaddrs.objects.filter(page='Security URL/QRcode').order_by('-Date')
    if request.method == 'POST':
        url=request.POST['url']
        request_url = ('http://tinyurl.com/api-create.php?' + urlencode({'url':url}))
        with contextlib.closing(urlopen(request_url)) as response:					
            urls=response.read().decode('utf-8 ')
        ips,showtime=get_client_ip(request)
        securityurl=securityurls(ipaddrs=ips,page='Security URL/QRcode',Date=showtime,passwd=urls)
        securityurl.save()
        return render(request,'securityurlqr.html',{'urls':urls,'ip':ip})
    else:
        return render(request,'securityurlqr.html',{'ip':ip})

def adminyoutubeplay(request):
    ip,showtime=get_client_ip(request)
    ids = securityyoutube.objects.filter(ipaddrs=ip,page='Youtube Bulk').order_by('-Date')
    head=['ID',"Ip Address","Trace Route","Date","Youtube Bulk"]
    print(head)
    return render(request,"base_table.html",{'ip':ip,'ids':ids,'head':head})


def youtubeplay(request):
    ip,showtime=get_client_ip(request)
    ipaddr=ipaddrs(ipaddrs=ip,page='Youtube Bulk',Date=showtime)
    ipaddr.save()
    if request.method == 'POST':
        urls=request.POST['urlplay']
        id=urls.split('/')[-1]
        print("https://getyoutubehd.com/v/"+str(id))
        ips,showtime=get_client_ip(request)
        securityyoutubes=securityyoutube(ipaddrs=ips,page='Youtube Bulk',Date=showtime,passwd=urls)
        securityyoutubes.save()
        return render(request,'youtubeplay.html',{'ip':ip,'id':id,'urls':urls})
    ip = ipaddrs.objects.filter(page='Youtube Bulk').order_by('-Date')
    return render(request,'youtubeplay.html',{'ip':ip})