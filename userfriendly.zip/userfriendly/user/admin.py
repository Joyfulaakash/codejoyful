from django.contrib import admin
from .models  import ipaddrs,securityip,imagemonformat,securityfinder,imagermformat,securitypasswds,imageformatss,imagerm,securityurls,securityyoutube,grammerchecks
# Register your models here.
admin.site.register(ipaddrs)
admin.site.register(securityip)
admin.site.register(securityfinder)
admin.site.register(imagermformat)
admin.site.register(securitypasswds)
admin.site.register(imagemonformat)
admin.site.register(imageformatss)
admin.site.register(imagerm)
admin.site.register(securityurls)
admin.site.register(securityyoutube)
admin.site.register(grammerchecks)