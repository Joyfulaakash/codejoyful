from . import views
from django.conf import settings
from django.conf.urls.static import static

from django.urls import path

urlpatterns = [
    path('', views.index ,name="index"),
    path('about', views.about ,name="about"),
    path('base', views.base ,name="base"),
    path('login', views.login ,name="login"),
    path('adminbase', views.adminbase ,name="adminbase"),
    path('contact', views.contact ,name="contact"),
    path('grammercheck', views.grammercheck ,name="grammercheck"),
    path('imagermbg', views.imagermbg ,name="imagermbg"),
    path('iamgformat', views.imagformat ,name="iamgformat"),
    path('securityfinder', views.securityfinder ,name="securityfinder"),
    path('securitypasswd', views.securitypasswd ,name="securitypasswd"),
    path('securityurlqr', views.securityurlqr ,name="securityurlqr"),
    path('youtubeplay', views.youtubeplay ,name="youtubeplay"),
    path('iplocation', views.iplocation ,name="iplocation"),
    path('translate', views.translate ,name="translate"),
    
    
    path('admingrammercheck', views.admingrammercheck ,name="admingrammercheck"),
    path('adminimagermbg', views.adminimagermbg ,name="adminimagermbg"),
    path('adminiamgformat', views.adminimagformat ,name="adminiamgformat"),
    path('adminsecurityfinder', views.adminsecurityfinder ,name="adminsecurityfinder"),
    path('adminsecuritypasswd', views.adminsecuritypasswd ,name="adminsecuritypasswd"),
    path('adminsecurityurlqr', views.adminsecurityurlqr ,name="adminsecurityurlqr"),
    path('adminyoutubeplay', views.adminyoutubeplay ,name="adminyoutubeplay"),
    
    
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
