from django import forms
from .models import *
  
class imagermForm(forms.ModelForm):
    class Meta:
        model = imagerm
        fields = ['Img']


class imageformatForm(forms.ModelForm):
    class Meta:
        model = imageformatss
        fields = ['Img','format']