from django.db import models

# Create your models here.


class ipaddrs(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    def __str__(self):
        return self.ipaddr


class grammerchecks(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=1000)
    def __str__(self):
        return self.ipaddrs


class securityurls(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=20)
    def __str__(self):
        return self.ipaddrs

class securityip(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=2000)
    def __str__(self):
        return self.ipaddrs


class securityyoutube(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=20)
    def __str__(self):
        return self.ipaddrs

class securityfinder(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=20)
    def __str__(self):
        return self.ipaddrs




class securitypasswds(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    passwd=models.CharField(max_length=20)
    def __str__(self):
        return self.ipaddrs

class imagemonformat(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    format=models.CharField(max_length=20)
    Img = models.ImageField(upload_to='images/')
    def __str__(self):
        return self.ipaddrs


# models.py
class imageformatss(models.Model):
    Img = models.ImageField(upload_to='images/')
    format = models.CharField(max_length=50)

class imagerm(models.Model):
	Img = models.ImageField(upload_to='images/')
    
class imagermformat(models.Model):
    ipaddrs=models.CharField(max_length=20)
    Date=models.CharField(max_length=30)
    page=models.CharField(max_length=20)
    Img = models.ImageField(upload_to='images/')
    def __str__(self):
        return self.ipaddrs
